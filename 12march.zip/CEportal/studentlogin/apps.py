from django.apps import AppConfig


class StudentloginConfig(AppConfig):
    name = 'studentlogin'
