from django.apps import AppConfig


class FacultyloginConfig(AppConfig):
    name = 'facultylogin'
